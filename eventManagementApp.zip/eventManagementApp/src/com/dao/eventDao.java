package com.dao;

import java.io.IOException;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

//import com.mysql.jdbc.log.Log;


import com.bean.*;
import com.util.DBConnectionEvent;

public class eventDao {
	public static List <event> getEventDetails(int ID) throws Exception{
		List<event> event=new ArrayList<>();
		
		event eventList=null;
		Connection con = null;
	    PreparedStatement statement = null;
	    ResultSet rs = null;
	    
	    try {
	    	con = DBConnectionEvent.createConnection();
	        String sql = "SELECT * FROM event where eventID='"+ID+"'";
	        statement=con.prepareStatement(sql);
	        rs=statement.executeQuery();
	      
	        
	        while(rs.next()) {
	        	int eventID=rs.getInt("eventID");
	        	String adminID =rs.getString("adminID");
				String eventName=rs.getString("eventName");
				String occasion=rs.getString("occasion");
				String date=rs.getString("date");
				String venue=rs.getString("venue");
				String chiefGuest=rs.getString("chiefGuest");
				eventList=new event(eventID,adminID,eventName,occasion,date,venue,chiefGuest);
				event.add(eventList);
	        	
	        }	  }catch(SQLException e) {
				printSQLException(e);
				
		}
		
		return event;
	    }
	
	
	public static List <event> getEventDetail() throws Exception{
		List<event> events=new ArrayList<>();
		
		//event eventList=null;
		Connection con = null;
	    PreparedStatement statement = null;
	    ResultSet rs = null;
	    
	    try {
	    	con = DBConnectionEvent.createConnection();
	         String sql = "SELECT * FROM event";
	         statement=con.prepareStatement(sql);
	       
	        rs=statement.executeQuery();
	        while(rs.next()) {
	        	int eventID=rs.getInt("eventID");
	        	String adminID =rs.getString("adminID");
				String eventName=rs.getString("eventName");
				String occasion=rs.getString("occasion");
				String date=rs.getString("date");
				String venue=rs.getString("venue");
				String chiefGuest=rs.getString("chiefGuest");
				events.add (new event(eventID,adminID,eventName,occasion,date,venue,chiefGuest));
	        	
	        }	  }catch(SQLException e) {
				printSQLException(e);
				
		}
		
		return events;
	    }
	
	
	
	public static List <event> searchEvent(String eventname) {
		List<event> event=new ArrayList<>();
		event eventList=null;
		Connection con = null;
	    PreparedStatement statement = null;
	    ResultSet rs = null;
	    
	    try {
	    	con = DBConnectionEvent.createConnection();
		       
		        String sql = "SELECT * FROM event WHERE eventname LIKE '"+eventname+"'";
		        		
		         statement=con.prepareStatement(sql);
		       
		       statement.setString(1,eventname);
		        rs=statement.executeQuery();
		        while(rs.next()) {
		        	int eventID=rs.getInt("eventID");
		        	String adminID =rs.getString("adminID");
					String eventName=rs.getString("eventName");
					String occasion=rs.getString("occasion");
					String date=rs.getString("date");
					String venue=rs.getString("venue");
					String chiefGuest=rs.getString("chiefGuest");
					eventList = new event(eventID,adminID,eventName,occasion,date,venue,chiefGuest);
					event.add(eventList);
		        	
		        }
	    	
	    
	    } catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return event;
		
	}
	
	

	private static void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}
}
	
	
	    
	
	
	
