package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import com.bean.*;
import com.util.DBConnectionEvent;



public class deleteEventDao {
		
	private static boolean isSuccess;
	private static Connection con = null;
	private static Statement statement = null;
	
		public static  boolean deleteEvent(int eventID) throws SQLException {
			/**
			boolean isSuccess = false ;
			Connection con = null;
			Statement statement = null;
			*/
			try {
				con = DBConnectionEvent.createConnection();
				statement = con.createStatement();
			    String sql = "delete from event where eventID='"+eventID+"'";
			    int rs = statement.executeUpdate(sql);
			     
			    if(rs>0) {
			    	isSuccess = true;
			    }
			    else {
			    	isSuccess = false;
			    }
			} catch (Exception e) {
				e.printStackTrace();
			}
			    
			   return isSuccess;
		}
		}
		

	
	
	
	
	