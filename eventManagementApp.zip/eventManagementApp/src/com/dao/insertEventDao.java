package com.dao;

import java.sql.Connection;

import com.util.DBConnectionEvent;




public class insertEventDao {
	
	public static boolean  insertEvent( int eventID,String adminID,String eventName,String occasion,String date,String venue, String chiefGuest)

    {
		 boolean isSuccess = false;
		 
   	 Connection con = null;
  
        
        try {
            con = DBConnectionEvent.createConnection();
            java.sql.Statement stmt = con.createStatement();
            String query = "insert into event values('"+eventID+"','"+adminID+"','"+eventName+"','"+occasion+"','"+date+"','"+venue+"','"+chiefGuest+"')";

            int res = stmt.executeUpdate(query);
           
            
            if(res > 0) {
                isSuccess = true;
            } else {
                isSuccess = false;
            }
			
			
		}
		
		catch (Exception e) {
			e.printStackTrace();
		}
				
		
		return isSuccess;
		
	}

}
