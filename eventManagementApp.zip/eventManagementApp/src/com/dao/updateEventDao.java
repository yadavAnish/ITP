package com.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.event;
import com.mysql.jdbc.PreparedStatement;
import com.util.DBConnectionEvent;





public class updateEventDao {
	private static boolean isSuccess;
	private static Connection con = null;
	private static Statement statement = null;
	
	
	
	public static boolean updateEvent(int eventID,String adminID,String eventName,String occasion,String date,
			String venue,String chiefGuest) throws Exception {
	

		try {
			con =  DBConnectionEvent.createConnection();
			statement=con.createStatement();
			
			String sql = "update event set eventID='"+eventID+"',AdminID='"+adminID+"',eventName='"+eventName+"',Occasion='"+occasion+"',Date='"+date+"',Venue='"+venue+"',ChiefGuest='"+chiefGuest+"'  " + " where eventID='"+eventID+"'";
			
			int rs=statement.executeUpdate(sql);
			
			
			if(rs>0) {
		    	 isSuccess = true;
		     }
		     else {
		    	 isSuccess = false;
		     }
			

		} catch (Exception e) {
			
			e.printStackTrace();		
	}
	return isSuccess;
	
	}
}
