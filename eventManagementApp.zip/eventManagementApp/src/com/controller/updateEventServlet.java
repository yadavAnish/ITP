package com.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.updateEventDao;
import com.dao.eventDao;
import com.dao.insertEventDao;
import com.bean.event;

/**
 * Servlet implementation class updateEventServlet
 */
@WebServlet("/updateEventServlet")
public class updateEventServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public updateEventServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		int eventID=Integer.parseInt(request.getParameter("eventID"));
		String adminID=request.getParameter("adminID");
		String eventName=request.getParameter("eventName");
		String occasion=request.getParameter("occasion");
		String date=request.getParameter("date");
		String venue=request.getParameter("venue");
		String chiefGuest=request.getParameter("chiefGuest");
		
		event updatedEvent=new event(eventID,adminID,eventName,occasion,date,venue,chiefGuest);
		
		try {
			updateEventDao.updateEvent(eventID,adminID,eventName,occasion,date,venue,chiefGuest);
			 //request.getRequestDispatcher("updateEvent.jsp").forward(request, response);
			RequestDispatcher dis = request.getRequestDispatcher("addEvent.jsp");
			dis.forward(request, response);
			
		} catch (Exception e) {
		
			e.printStackTrace();
		}
		
		
	       
	}
	
	
     

}
