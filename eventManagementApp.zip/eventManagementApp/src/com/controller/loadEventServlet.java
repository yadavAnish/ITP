package com.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.event;
import com.dao.eventDao;

/**
 * Servlet implementation class loadEventServlet
 */
@WebServlet("/loadEventServlet")
public class loadEventServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loadEventServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
			int eventID=Integer.parseInt(request.getParameter("eventID"));
			System.out.println("eventID");
			System.out.println(eventID);
			List<event> existingEvent = null;
			try {
				existingEvent = eventDao.getEventDetails(eventID);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			RequestDispatcher dispatcher=request.getRequestDispatcher("updateEvent.jsp");
			request.setAttribute("event",existingEvent);
			dispatcher.forward(request, response);
		
		
	}

}
