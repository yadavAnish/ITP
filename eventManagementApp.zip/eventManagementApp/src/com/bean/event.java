package com.bean;

public class event {
	private int eventID;
	private String adminID;
	private String eventName;
	private String occasion ;
	private String  date;
	private String venue;
	private String chiefGuest;
	
	
	public event(int  eventID, String adminID, String eventName, String occasion, String date, String venue,
			String chiefGuest) {
		super();
		this.eventID = eventID;
		this.adminID = adminID;
		this.eventName = eventName;
		this.occasion = occasion;
		this.date = date;
		this.venue = venue;
		this.chiefGuest = chiefGuest;
	}


	public event(String adminID, String eventName, String occasion, String date, String venue, String chiefGuest) {
		super();
		this.adminID = adminID;
		this.eventName = eventName;
		this.occasion = occasion;
		this.date = date;
		this.venue = venue;
		this.chiefGuest = chiefGuest;
	}
	
	public event(String eventName) {
		super();
		this.eventName = eventName;
		
	}
	

	public int getEventID() {
		return eventID;
	}


	public void setEventID(int eventID) {
		this.eventID = eventID;
	}


	public String getAdminID() {
		return adminID;
	}


	public void setAdminID(String adminID) {
		this.adminID = adminID;
	}


	public String getEventName() {
		return eventName;
	}


	public void setEventName(String eventName) {
		this.eventName = eventName;
	}


	public String getOccasion() {
		return occasion;
	}


	public void setOccasion(String occasion) {
		this.occasion = occasion;
	}


	public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}


	public String getVenue() {
		return venue;
	}


	public void setVenue(String venue) {
		this.venue = venue;
	}


	public String getChiefGuest() {
		return chiefGuest;
	}


	public void setChiefGuest(String chiefGuest) {
		this.chiefGuest = chiefGuest;
	}
	

}